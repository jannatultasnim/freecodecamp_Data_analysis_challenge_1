import numpy as np

def calculate(list):
    if len(list)!= 9:
       raise ValueError("List must contain nine numbers.")
    my_list= np.array(list)
    mean_row=[my_list[[0,1,2]].mean(),my_list[[3,4,5]].mean(),my_list[[6,7,8]].mean()]
    mean_col= [my_list[[0,3,6]].mean(),my_list[[1,4,7]].mean(),my_list[[2,5,8]].mean()]
  
    var_row = [my_list[[0,1,2]].var(),my_list[[3,4,5]].var(),my_list[[6,7,8]].var()]
    var_col = [my_list[[0,3,6]].var(),my_list[[1,4,7]].var(),my_list[[2,5,8]].var()]
  
    std_row= [my_list[[0,1,2]].std(),my_list[[3,4,5]].std(),my_list[[6,7,8]].std()]
    std_col = [my_list[[0,3,6]].std(),my_list[[1,4,7]].std(),my_list[[2,5,8]].std()]

    max_row = [my_list[[0,1,2]].max(),my_list[[3,4,5]].max(),my_list[[6,7,8]].max()]
    max_col = [my_list[[0,3,6]].max(),my_list[[1,4,7]].max(),my_list[[2,5,8]].max()]

    min_row = [my_list[[0,1,2]].min(),my_list[[3,4,5]].min(),my_list[[6,7,8]].min()]
    min_col = [my_list[[0,3,6]].min(),my_list[[1,4,7]].min(),my_list[[2,5,8]].min()]

    sum_row = [my_list[[0,1,2]].sum(),my_list[[3,4,5]].sum(),my_list[[6,7,8]].sum()]
    sum_col = [my_list[[0,3,6]].sum(),my_list[[1,4,7]].sum(),my_list[[2,5,8]].sum()]
    return {
        'mean': [mean_col, mean_row, my_list.mean()],
        'variance': [var_col, var_row, my_list.var()],
        'standard deviation': [std_col, std_row, my_list.std()],
        'max': [max_col, max_row, my_list.max()],
        'min': [min_col, min_row, my_list.min()],
        'sum': [sum_col,sum_row,my_list.sum()]
}